// index.js 

import * as ClientListBusiness from "./client-list-business";

window.onload = function() {
  ClientListBusiness.printClientsAccounts();
};

